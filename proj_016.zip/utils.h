/******************************************************************************
 *
 * File Name: uitls.h
 *	      (c) 2018 AED
 * Authors:    Ana Isabel Ventura, Diana Oliveira
 * Last modified:  11/05/2018
 *
 * COMMENTS
 *			useful functions
 *
 *****************************************************************************/

#ifndef _UTILS_H
#define _UITLS_H

/*Declaration of libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "matrix.h"

/*Declaration of functions*/
int Solve(FILE *fpIn , FILE *fpOut);
int MaxEnergy(t_matrix *Mat,t_cell *path,t_cell *ref_path, int k, int ll, int cl,int Ll, int Cl, int k0, int E);
int MinEnergy(t_matrix *Mat,t_cell *path, int ll, int cl, int obj, int k,  int Ll, int Cl, int k0, int E);
int Conditions(t_matrix *Mat, int ll, int cl, int Ll, int Cl, int k, int k0, int obj);
int move(t_matrix *Mat, t_cell *path, int ll, int cl, int k0);
int AddAll(t_matrix *, int L, int C, int l, int c, int k);
void WriteFile(FILE *fpOut, t_matrix *ma, t_cell *path, int L, int C, int k,int obj, int E, int l, int c);

#endif
