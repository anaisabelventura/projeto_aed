/******************************************************************************
 *
 * File Name: utils.c
 *	      (c) 2018 AED
 * Authors:    Ana Isabel Ventura, Diana Oliveira
 * Last modified: 15/05/2018
 *
 * COMMENTS
 *		Useful functions
 *
 *****************************************************************************/
#include "matrix.h" 
#include "utils.h" 
/******************************************************************************
 * erroFileData ()
 *
 * Arguments: msg - pointer to message to print
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: print to standard error output an allocation error message
 *****************************************************************************/
void errFileData( ){
  exit(0);
}
/******************************************************************************
 *  Solve(FILE *fpIn , FILE *fpOut)
 *
 * Arguments: fpIn - pointer to input file
 *			  fpOut - pointer to output file
 * Returns: int
 * Side-Effects: none
 *
 * Description: main function for problem solving
 *****************************************************************************/
int Solve(FILE *fpIn , FILE *fpOut){
	/*Declaration and inicialization of variables*/
	t_matrix *newPuzzle;
	t_cell *path=NULL,  *ref_path=NULL;
	int i, j;
	int entry;
	int  L, C, l, c, k, ll, cl, E, obj, k0;
	int l_p, lp, c_p, cp, Ll,Cl;
 	L=C=l=c=k=l_p=lp=c_p=cp=Ll=Cl=ll=cl=E=obj=k0=0;
 	i=j=0;
 	entry=0;
 	while( 1 ){
 		/*scan first line containing information to solve the puzzle*/
		if(fscanf(fpIn,"%d %d %d %d %d %d %d", &L, &C, &obj, &l, &c, &k, &E)!=7) 
			break;

	  	if(c<=0 ||l<=0 || c>C || l>L){/*if coordinates of the starting cell don't belong within the matrix dimensions*/
			fprintf(fpOut, "%d %d %d %d %d %d %d\n\n", L, C, obj, l,c, k, E); /*L C obj l c k E*/
			for(i=0; i<L; i++)
		   		for(j=0; j<C; j++)
		   			if(fscanf(fpIn, "%d", &entry)!=1)
		   				errFileData();
		}	
		else if(obj<=0 && obj!=-2){ /*if the objective to the puzzle is none of the possible ones*/
		  	fprintf(fpOut, "%d %d %d %d %d %d %d\n\n", L, C, obj, l,c, k, E); /*L C obj l c k E*/
		  	for(i=0; i<L; i++)
		    	for(j=0; j<C; j++)
		    		if(fscanf(fpIn, "%d", &entry)!=1)
		    			errFileData();
		}
		else if(k<0 || k>=(L*C)){ /*if k steps is negative or too big to the matrix dimensions LxC*/
		  	fprintf(fpOut, "%d %d %d %d %d %d %d", L, C, obj, l,c, k, E); /*L C obj l c k E*/
		  	if(k>=(L*C))/*if k is bigger (or equal) than the number of cells of the matrix (L*C)*/
		  		fprintf(fpOut, " -1\n\n");	  		
		  	else fprintf(fpOut, "\n\n");
		  	for(i=0; i<L; i++)
		    	for(j=0; j<C; j++)
		    		if(fscanf(fpIn, "%d", &entry)!=1)
		    			errFileData();
		}
		else if(E<=0){ /*if the given starting energy for the agent is not positive*/
		  	fprintf(fpOut, "%d %d %d %d %d %d %d\n\n", L, C, obj, l,c, k, E); /*L C obj l c k E*/
		  	for(i=0; i<L; i++)
		    	for(j=0; j<C; j++)
		    		if(fscanf(fpIn, "%d", &entry)!=1)
		    			errFileData();
		}
	  	else {
	  		/*Determine local matrix of smaller dimensions (within the global one) accordingly to k given - it's dimensions and frontiers*/
			/*check if frontiers of the local matrix are within the global matrix*/
	  		/*if not, set the first to the respective frontier of the global matrix*/
		  	if(l-abs(k)<=0) l_p=0;/*up*/
		 		else l_p=l-abs(k)-1;
		 	if(l+abs(k)>L) lp=L-1;/*down*/
		 		else lp=l+abs(k)-1;
		 	if(c-abs(k)<=0) c_p=0;/*left*/
		 		else c_p=c-abs(k)-1;
		 	if(c+abs(k)>C) cp=C-1;/*right*/
		 		else cp=c+abs(k)-1;
			Ll=lp-l_p+1;
			Cl=cp-c_p+1;
			/*Conversion of universal coordenates to local coordenates*/
			/*and create new main struct*/
		    newPuzzle=NewMatrix(Ll,Cl,k,l,c, E);
		     /*fill and save the matrix*/
		    for(i=0; i<L; i++)
		    	for(j=0; j<C; j++){
		    		if(fscanf(fpIn, "%d", &entry)!=1)
		    			errFileData();
		    		if((i>=l_p && i<=lp)&&(j>=c_p && j<=cp))
		    			SetMapElement(newPuzzle, entry,i-l_p, j-c_p);	
				}

			if ((Ll<L)||(Cl<C)){
				ll=abs(k);
				cl=abs(k);
				/*transform the coordentas system so that (0,0) is the first cell possible, instead of (1,1,)*/
				if(l_p==0)
					ll=Ll-abs(k)-1;
				else if(lp==L)
					ll=abs(k)-1;
					
				if(c_p==0)
					cl=Cl-abs(k)-1;
				else if(cp==C)
					cl=abs(k)-1;
			}

			if(Ll>=L) ll=l-1;
			if (Cl>=C) cl=c-1;

			if(k!=0){	
				/*Solve the problem*/
				/*Create path and set the starting cell usage to 1*/
				path=CreatePath(k);
				SetCellUsage(newPuzzle, ll, cl,1);
				if(obj==-2){
					/*obj=-2 implies the search of maximum energy within k steps*/
					/*Create path of reference of k+1 positions*/
					/*where the first position has the energy value of the respective path for future comparison*/
					ref_path=CreatePath(k+1); 
					/*Function for maximum energy*/
					MaxEnergy(newPuzzle, path, ref_path, k,ll,  cl, Ll, Cl, k0, E);
				}else if(obj>0)/*obj positive implies the search for a path that generates a minimum energy value equal to obj*/
					/*Function for minimum energy*/
					MinEnergy(newPuzzle, path, ll, cl,  obj, k, Ll, Cl, k0, E);
			}else if(k==0){/*implies zero steps to be given*/
				SetMapEnergy(newPuzzle, GetEnergy(newPuzzle));
				if(GetEnergy(newPuzzle)<obj)
					SetMapEnergy(newPuzzle, -1);
			}
			/*conversion of the local coordenates to the universal ones (refering to the original matrix)*/
			CoordinateConvergence(path, k, l_p, c_p);
			/*Write solution on the file*/
			WriteFile(fpOut,newPuzzle,path, L, C,k,obj, E, l, c);
			/*Free matrix and path memory*/
			if(obj==-2) free(ref_path);
			free(path);
			FreeMatrix(newPuzzle, Ll);
		}
	}
	return 0;
}
/******************************************************************************
 *  MaxEnergy(t_matrix *Mat, t_cell *path, t_cell *ref_path,int k, int ll, in cl, int Ll, int Cl, int k0, int E)
 *
 * Arguments: Mat -(t_matrix *)pointer to structure with map(puzzle) an other 
 *					important variables 
 *			  path - (t_cell) pointer to array of structures with coordinates 
 *					and cost or prize of each cell in the path chosen.
 * 			  ref_path - (t_cell) pointer to array of structures with coordinates 
 *					and cost or prize of each cell in the best path found do far
 * 			  k - (int) number passes
 *			  Ll, Cl - (int) dimensions of map
 *	          ll, cl -(int) coordinates of the current position
 *			  k0 - (int) number of passes taken
 *			  E - agent's initial energy
 * Returns: (int)
 * Side-Effects: none
 *
 * Description: function that determines the best path with maximum energy of 
 *				the map
 *****************************************************************************/
int MaxEnergy(t_matrix *Mat, t_cell *path, t_cell *ref_path, int k,int ll, int cl, int Ll,int Cl, int k0, int E){

	/*Find path with more energy than the one for the path saved in ref_path */
	if(MinEnergy(Mat,path, ll, cl, GetCellValue_array(ref_path, 0)+1, k, Ll, Cl, k0, E)==1){ /*if search is successful*/
		if(GetEnergy(Mat)>=GetCellValue_array(ref_path, 0)+1){ /*if the last energy found is bigger than the one already saved in the ref_path*/
			/*Save new path in ref_path for future reference*/
			transfer_path(path,ref_path, k, GetEnergy(Mat));
			SetMapEnergy(Mat,E); /*Reset the agent's total energy to his initial energy in the main stucture in order to be able to find a new path*/
			Visited(path,Mat, k); /*Reset flag visited in the main structure for every cell in the path in order to use map again in the new search*/
			if(MaxEnergy(Mat, path, ref_path, k,ll, cl, Ll,Cl, k0, E)==1) /*if search is successful*/
				return 1; /*suceess*/
		}
	}else if(GetCellValue_array(ref_path, 0)<=0){ /*if it is not possible to find a path where the agent is alive at the end*/
		SetMapEnergy(Mat, -1); /*rthen the problem doesn't have a solution*/
		return 0; /*/*insuceess*/

	}else{ /*if there was a path found after exploring the whole tree*/
		path_transfer(Mat, path, ref_path, k, E); /*transfer path saved in ref_path to path*/
		return 1; /*/*suceess*/
	}
	return 1; /*suceess*/
}
/******************************************************************************
 *  MinEnergy(t_matrix *Mat, t_cell *path, int ll, in cl, int obj, int k, int Ll, int Cl, int k0, int E)
 *
 * Arguments: Mat -(t_matrix *)pointer to structure with map(puzzle) an other 
 *					important variables 
 *			  path - (t_cell) pointer to array of structures with coordinates 
 *					and cost or prize of each cell in the path chosen.
 *			  Ll, Cl - (int) dimensions of map
 *	          ll, cl -(int) coordinates of the current position
 *			  k - (int) number passes
 *			  k0 - (int) number of passes taken
 *		      obj - puzzle objective 
 *			  E - agent's initial energy
 * Returns: (int)
 * Side-Effects: none
 *
 * Description: function that determines the first path to reach or surpass the
				minimum energy set as objective
 *****************************************************************************/
int MinEnergy(t_matrix *Mat,t_cell *path, int ll, int cl, int obj, int k, int Ll, int Cl, int k0, int E){

	int i;
	i=0;
	if(k-k0>=0 && k0<k){ /*if the current step is within the limitis of the passes*/
		for(i=0; i<4; i++){
			switch(i){
				case 0:{ /*up*/
					if(Conditions(Mat,ll-1, cl, Ll, Cl, k, k0, obj)==1){/*if every condition is met*/
						move(Mat,path, ll-1, cl,k0);/*make movement for cell above*/
						if(MinEnergy(Mat,path, ll-1, cl, obj, k, Ll, Cl, k0+1, E)==1)
							return 1;/*sucess*/
					}
					break;
				}
				case 1:{/*down*/
					if(Conditions(Mat,ll+1, cl, Ll,Cl, k, k0+1, obj)==1){/*if every condition is met*/
						move(Mat,path, ll+1, cl,k0);/*make movement for cell beneath*/
						if(MinEnergy(Mat,path, ll+1, cl, obj, k, Ll, Cl, k0+1, E)==1)
							return 1;/*sucess*/
					}
					break;
				}			
				case 2:{ /*left*/
					if(Conditions(Mat,ll, cl-1, Ll,Cl, k, k0, obj)==1){/*if every condition is met*/
						move(Mat,path, ll, cl-1, k0);/*make movement for cell to the left*/
						if(MinEnergy(Mat,path, ll, cl-1, obj, k, Ll, Cl, k0+1, E)==1)
							return 1;/*sucess*/
					}
					break;
				}
				case 3:{ /*right*/
					if(Conditions(Mat,ll, cl+1, Ll,Cl, k, k0, obj)==1){/*if every condition is met*/
						move(Mat,path, ll, cl+1,k0);/*make movement for cell to the right*/
						if(MinEnergy(Mat,path, ll, cl+1, obj, k, Ll, Cl, k0+1, E)==1)
							return 1;/*sucess*/
					}
					break;
				}
			}
		}
		if (k0==0 && (GetEnergy(Mat)-E)<obj){ /*if every decision has been explored and the agent's energy is smaller than the the target*/
			SetMapEnergy(Mat, -1); /*problem has no solution*/
			return 0;/*insucess*/
		}

		if(k0-1>=0){
			/*reset energy*/
			SetMapEnergy(Mat, GetEnergy(Mat)-GetCellValue(Mat, GetCellline_array(path, k0-1), GetCellcolumn_array(path, k0-1)));
			/*Deactivate flag visited*/
			SetCellUsage(Mat, GetCellline_array(path, k0-1), GetCellcolumn_array(path, k0-1), 0);
		}
		/*the last decision does not lead to any valid path, so it is necessary to go back and explore the other directions*/
		return 0; /*insucess*/

	} else if(k0==k-1 && GetEnergy(Mat)>=obj) /*if all the passes have been taken and the agent's energy is bigger than the target*/
		return 1;/*sucess*/
	if(k0-1>=0 && GetEnergy(Mat)<obj){
		/*reset energy*/
		SetMapEnergy(Mat, GetEnergy(Mat)-GetCellValue(Mat, GetCellline_array(path, k0-1), GetCellcolumn_array(path, k0-1)));
		/*Deactivate flag visited*/
		SetCellUsage(Mat, GetCellline_array(path, k0-1), GetCellcolumn_array(path, k0-1), 0);
		/*the last decision does not lead to any valid path, so it is necessary to go back and explore the other directions*/
		return 0; /*sucess*/
	}
	return 1; /*sucess*/
}
/******************************************************************************
 * Conditions(t_matrix *Mat, int ll, int cl, int Ll, int Cl, int k, int k0, int obj)
 *
 * Arguments: Mat -(t_matrix *)pointer to structure with map(puzzle) an other 
 *					important variables 
 *	          ll, cl -(int) coordinates of the current cell
 *			  Ll, Cl - (int) dimensions of map
 *			   k - (int) number passes
 *			   k0 - (int) number of passes taken
 *		      obj - puzzle objective
 * Returns: (int)
 * Side-Effects: none
 *
 * Description: function that determines the sum of every cell with a positive
 *				prize within a certain radius 
 *****************************************************************************/
int Conditions(t_matrix *Mat, int ll, int cl, int Ll, int Cl, int k, int k0, int obj){

	int Up; 

	if(ll>=0 && ll<Ll && cl>=0 && cl<Cl){/*if coordinates of the next cell don't belong within the matrix dimensions*/
		if(GetCellUsage(Mat, ll, cl)==0) /*if cell is not a part of the path*/
			if(GetCellValue(Mat, ll, cl)+GetEnergy(Mat)>0){/*if moving to the next cell does not kill the agent*/
				/*Add all cell wiith prize within a k-x radius plus th cost/prize of the next cell plus agent's energy*/
				Up=AddAll(Mat, Ll, Cl, ll, cl, k-k0) + GetEnergy(Mat)+GetCellValue(Mat, ll, cl); 
				if(Up>=obj)/*if Upper bound is valid*/
					return 1; /*success, movement is valid*/
			}
	}	
	return 0; /*insuccess,  movement is not valid*/
}
/******************************************************************************
 *  move(t_matrix *Mat, t_cell *path, int ll, int cl, int k0)
 *
 * Arguments: Mat -(t_matrix *)pointer to structure with map(puzzle) an other 
 *					important variables 
 *			  path - pointer to array of structure with path taken
 *	          ll, cl -(int) coordinates of the next cell
 *			   k0 - (int) number of passes taken
 * Returns: (int)
 * Side-Effects: none
 *
 * Description: function that implements the movement to the (ll, cl) cell, 
 *	updates the agent energy and activates the flag visited.
 *****************************************************************************/
int move(t_matrix *Mat, t_cell *path, int ll, int cl, int k0){

	/*Visited ==1*/
	SetCellUsage(Mat, ll, cl, 1);
	/*save to path*/
	path=SetArrayElement(path, k0, Mat,ll, cl);
	/*update energy*/
	SetMapEnergy(Mat,GetEnergy(Mat)+GetCellValue(Mat, ll, cl));

	return 0;
}
/******************************************************************************
 *  AddAll(t_matrix *Mat, int L, int C, int l, int c, int k)
 *
 * Arguments: Mat -(t_matrix *)pointer to structure with map(puzzle) an other 
 *					important variables 
 *			  L, C - (int) dimensions of map
 *	          l, c -(int) coordinates of the inicial position
 *			   k - (int) number of cells inbetween the initial and final position
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: function that determines the sum of every cell with a positive
 *				prize within a certain radius 
 *****************************************************************************/
int AddAll(t_matrix *Mat, int L, int C, int l, int c, int k){
	/*declaration and inicialization of variables*/
	int nl, nc, total;
	nl=nc=total=0;
	/*if the cell it's not within the matrix's frontiers*/
	if(l<0 || l>=L || c<0 || c>=C)
		SetMapEnergy(Mat,-1);
	else{
		/*runs through all cells in a k-radius from top to bottom, from left to right*/
		for(nl=l-k; nl<=l+k && nl<L; nl++){
			/*the first cell has l-k line coordenate*/
			/*if the first cell in a k-radius has negative line coordenate*/			
			if(nl<0) nl=0;	/*the line coordenate becomes zero, as to start in the first line of the puzzle*/

			for(nc=c-k+abs(l-nl); nc<=c+k-abs(l-nl) && nc<C; nc++){
				/*the first cell has (c-k+abs(l-nl)) column coordenate*/
				/*if the first cell in a k-radius has negative column coordenate*/			
				if(nc<0) nc=0;/*the column coordenate becomes zero, as to start in the first column of the puzzle*/
							
				/*if the cell value is positive, has never been used, and it is not the starting cell*/
							
				if((nl!=l && nc!=c) || (nl!=l && nc==c) || (nl==l && nc!=c))
					if(GetCellValue(Mat, nl, nc)>0)
						if(GetCellUsage(Mat, nl, nc)==0) /*than it is added to the total*/
							total += GetCellValue(Mat, nl, nc);
			}
		}
		
	}
	/*return the value determined*/
	return total;
}
/******************************************************************************
 *  WriteFile(FILE *fpOut, t_matrix *ma, t_cell *path, int L, int C, int k,
 *       int obj, int E, int l, int c)
 *
 * Arguments: fpOut - pointer to output file
 *			  ma -(t_matrix *)pointer to structure with map(puzzle) an other 
 *					important variables 
 *			  path - pointer to array of structure with path taken
 *			  L, C - (int) dimensions of map
 *		  	  k - (int) lenght of the array of structs that holds the path
 *            obj - puzzle objective 
 *			  E - Inicial agent energy 
 *	          l, c -(int) coordinates of the inicial position
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: function that writes the solution in the desired format in the
 *				output file
 *****************************************************************************/
void WriteFile(FILE *fpOut, t_matrix *ma, t_cell *path, int L, int C, int k,int obj, int E, int l, int c){

	int i;
	i=0;
	/*if objetive is valid*/
	if(obj==-2 || obj>0){
		/*print first line*/
		fprintf(fpOut, "%d %d %d %d %d %d %d %d\n", L, C, obj, l,c, k, E, GetEnergy(ma)); /*L, C, obj, l,c, k, E*/
			if(k>0 && GetEnergy(ma)!=-1) /*if puzzle has solution and number of passes valid*/
				for(i=0; i<k; i++)
					fprintf(fpOut, "%d %d %d\n", GetCellline_array(path, i),GetCellcolumn_array(path, i), GetCellValue_array(path, i));/*li ci ki*/
	}
	fprintf(fpOut,"\n");
	return;
}