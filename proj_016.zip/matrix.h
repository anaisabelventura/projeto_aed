/******************************************************************************
 *
 * File Name: matrix.h
 *	      (c) 2018 AED
 * Authors:    Ana Isabel Ventura, Diana Oliveira
 * Last modified: 11/05/2018
 *
 * COMMENTS
 *		Structure and prototypes for type matrix and type cell
 *
 *****************************************************************************/

#ifndef _MATRIX_H
#define _MATRIX_H


/* type definition for structure to hold cell*/
typedef struct _t_cell t_cell;
/* type definition for structure to hold puzzle(matrix)*/
typedef struct _t_matrix t_matrix;

/*Declaration of functions for t_cell structure*/
t_cell *CreatePath(int lenght);
t_cell * SetArrayElement(t_cell *path, int place, t_matrix *ma, int l, int c);
int GetCellValue_array(t_cell *path, int k);
int GetCellline_array(t_cell *path, int k);
int GetCellcolumn_array(t_cell *path, int k);
void CoordinateConvergence(t_cell *path,int k0,int l_p, int c_p);
void transfer_path(t_cell *path, t_cell *ref_path, int k, int E);
void path_transfer(t_matrix *Mat, t_cell *path, t_cell *ref_path, int k, int E);

/*Declaration of functions for t_matrix structure*/
t_matrix  *NewMatrix(int L, int C, int k, int l, int c, int E);
void FreeMatrix(t_matrix *ma, int L);
void SetMapElement(t_matrix *ma, int value, int l, int c);
void SetMapEnergy(t_matrix *ma, int value);
void SetCellUsage(t_matrix *ma, int l, int c, int b);
int GetEnergy(t_matrix *ma);
int GetCellValue(t_matrix *ma, int l, int c);
int GetCellUsage(t_matrix *ma, int l, int c);
void Visited(t_cell *path, t_matrix *mat, int k);

#endif
