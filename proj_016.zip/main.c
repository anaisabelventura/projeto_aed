/******************************************************************************
 *
 * File Name: main.c
 *        (c) 2018 AED
 * Authors:    Ana Isabel Ventura, Diana Oliveira
 * Last modified: 11/05/2018
 *
 * COMMENTS
 *    Main program
 *
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "matrix.h"
#include "utils.h"
/******************************************************************************
 * Usage ()
 *
 * Arguments: nomeProg - name of executable
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: exit program when arguments are missing
 *
 *****************************************************************************/
void Usage(char *nameProg){
  /*exit program without output message*/
  exit(0);
}
/******************************************************************************
 * main ()
 *
 * Arguments: argc - number of command-line arguments
 *            argv - table of pointers for string arguments
 * Returns: int
 * Side-Effects: none
 *
 * Description: main Program
 *
 *****************************************************************************/
int main(int argc, char *argv[]){
  /*Declaration of variables*/
  char *fileNameIn = NULL; 
  char *fileNameOut = NULL; 
  const char ext[6]=".maps";
  const char extf[7]=".paths";
  int size;
  FILE *fpIn, *fpOut ;

  /* check if the program was correctly executed */
  if(( argc < 2 )||(argc > 2))
    Usage( argv[0] );

  /* check if file is .1maps */
  fileNameIn = argv[1];
  if(strstr(fileNameIn, ext)==NULL) exit(0); 
  /*open input file in order to read it*/
  fpIn = fopen( fileNameIn, "r" );
  /*see if file exists*/
  if( fpIn == NULL ) exit(0);

  /*Create name of output file*/
    /*find size of filename without the .1maps extension*/
  size=strlen(fileNameIn)-strlen(ext); 
    /*create memory for output file name wiht correct lenght*/
  fileNameOut=(char *)malloc(sizeof(char)*(size+strlen(extf)+1)); 
  if(fileNameOut == NULL) exit(0);

   /*copy name without the extension*/
  strncpy(fileNameOut, fileNameIn, size);
  fileNameOut[size]='\0';
  /*attach extension .query to filename*/
  fileNameOut = strcat(fileNameOut, extf); 
  /*Create output file*/
  fpOut = fopen( fileNameOut, "wr" );
  if( fpOut == NULL ) exit(0);

  /*Main function for puzzle solving*/
  Solve(fpIn, fpOut);

  /* free all alocated memory */
  free(fileNameOut);

  /* close all files */
  fclose(fpIn);
  fclose(fpOut);

  return 0;
}
