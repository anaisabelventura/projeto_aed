/******************************************************************************
 *
 * File Name: list.c
 *        (c) 2018 AED
 * Authors:    Ana Isabel Ventura, Diana Oliveira
 * Last modified:  11/05/2018
 *
 * COMMENTS
 *    implements functions for type matrix and type cell
 *
 *****************************************************************************/
#include <strings.h>
#include <stdio.h>

#include "matrix.h"
#include "utils.h"

/*Cell and variables needed in order to solve puzzle*/
struct _t_cell{
	int visited;
	int value; /* cell cost/prize*/
	int l, c; /* cell coordinates*/
};
/*Matrix and variables needed in order to solve puzzle*/
struct _t_matrix{
	int energy; /*agent enerby*/
	struct _t_cell **map; /*map that represents the puzzle*/
};
/******************************************************************************
 *  CreatePath(int lenght)
 *
 * Arguments: lenght - number of cells in path
 *			  
 * Returns: (t_cell *)
 * Side-Effects: none
 *
 * Description: function to create array of strutures to hold the path taken
 *****************************************************************************/
t_cell *CreatePath(int lenght){

	int i;
	i=0;
	/*memory allocation for new array of structures*/
	t_cell *path=(t_cell *)malloc(lenght*sizeof(t_cell));
	for(i=0; i<lenght; i++){
		/*inicialization of variables*/
		path[i].visited=0;
		path[i].value=0;
		path[i].l=0;
		path[i].c=0;
	}

	return path;
}
/******************************************************************************
 *  SetArrayElement(t_cell *path, int place, t_matrix *ma, int l, int c)
 *
 * Arguments: path - pointer to array of structure with path taken
 *			  place - placement in array
 *			  ma -	pointer to structure with map
 *			  l, c - coordinates of cell 
 * Returns: (t_cell *)
 * Side-Effects: none
 *
 * Description: function to fill each cell of the path with the correct information
 *****************************************************************************/
t_cell *SetArrayElement(t_cell *path, int place, t_matrix *ma, int l, int c){

	/*Transfer information from cell to path[place]*/
	path[place].visited=1; /*1because it is part of the path*/
	path[place].value=ma->map[l][c].value;
	path[place].l=l;
	path[place].c=c;
	return path;
}
/******************************************************************************
 *  NewMatrix(int L, int C, int k, int l, int c)
 *
 * Arguments: L,C - dimensions of map
 *			  k - number of steps/cells in path
 *			  l,c - initial position coordinates
 * Returns: (t_matrix *)
 * Side-Effects: none
 *
 * Description: function to create main struture with the map and each of its cell
 *****************************************************************************/
t_matrix  *NewMatrix(int L, int C, int k, int l, int c, int E){

	int i, j;
	i=j=0;

	/*memory allocation for new structure*/
	t_matrix *Mat =(t_matrix *)malloc(sizeof(t_matrix));

	Mat->map=(t_cell **)malloc(L*sizeof(t_cell *)); /*map lines*/
	for(i=0; i<L; i++)
		Mat->map[i]=(t_cell *)malloc(C*sizeof(t_cell)); /*map columns*/

	/*inicialization of variables*/
	for(i=0; i<L; i++)
		for(j=0; j<C; j++){
			Mat->map[i][j].visited=0;
			Mat->map[i][j].value=0;
			Mat->map[i][j].l=0;
			Mat->map[i][j].c=0;
		}

	Mat->energy=E;

	return Mat;
}
/******************************************************************************
 *  FreeMatrix(t_matrix *ma, int L, int C)
 *
 * Arguments: ma - pointer to t_matrix structure
 *			  L - number of lines in map
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: function to free memory allocated to the main structure
 *****************************************************************************/
void FreeMatrix(t_matrix *ma, int L){
	int i;
	/*free double pointers*/
	for (i=0; i<L; i++)
		free(ma->map[i]);

	free(ma->map);	/*free pointer to struct of cell*/
	free(ma); /*free pointer to main struct*/
	return;
}
/******************************************************************************
 *  SetMapElement(t_matrix *ma, int value, int l, int c)
 *
 * Arguments: ma - pointer to structure  t_matrix
 *			  value - value associated with the cost/prize of cell
 *			  l,c - initial position coordinates
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: function to link cost/prize of a certain cell to the respective
 *			t_cell struct
 *****************************************************************************/
void SetMapElement(t_matrix *ma, int value, int l, int c){
	ma->map[l][c].value=value;
	return;
}
/******************************************************************************
 * GetCellValue_array(t_cell *path, int k)
 *
 * Arguments: path - pointer to array of structs t_cell
 *			  k - placement of the wanted cell in the array
 * Returns: (int)
 * Side-Effects: none
 *
 * Description: function to get cost/prize of a certain cell in the path 
 *****************************************************************************/
int GetCellValue_array(t_cell *path, int k){
	return path[k].value;
}
/******************************************************************************
 * GetCellline_array(t_cell *path, int k)
 *
 * Arguments: path - pointer to array of structs t_cell
 *			  k - placement of the wanted cell in the array
 * Returns: (int)
 * Side-Effects: none
 *
 * Description: function to get line coordinate of a certain cell in the path 
 *****************************************************************************/
int GetCellline_array(t_cell *path, int k){
	return path[k].l;
}
/******************************************************************************
 * GetCellcolumn_array(t_cell *path, int k)
 *
 * Arguments: path - pointer to array of structs t_cell
 *			  k - placement of the wanted cell in the array
 * Returns: (int)
 * Side-Effects: none
 *
 * Description: function to get column coordinate of a certain cell in the path 
 *****************************************************************************/
int GetCellcolumn_array(t_cell *path, int k){
	return path[k].c;
}
/******************************************************************************
 *  SetMapEnergy(t_matrix *ma, int value)
 *
 * Arguments: ma - pointer to structure  t_matrix
 *			  value - value associated with the cost/prize of cell
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: function to link agent energy to the respective map
 *****************************************************************************/
void SetMapEnergy(t_matrix *ma, int value){
	ma->energy=value;
	return;
}
/******************************************************************************
 *  SetCellUsage(t_matrix *ma, int l, int c)
 *
 * Arguments: ma - pointer to structure  t_matrix
 *			  l,c - initial position coordinates
 *			   b - binary value of flag, either 1 if it's part of the path or 0
 *			 	if it's not
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: function to activate or deactivate flag visited associated to 
 *	a certain cell
 *****************************************************************************/
void SetCellUsage(t_matrix *ma, int l, int c, int b){
	ma->map[l][c].visited=b;
	return;
}
/******************************************************************************
 *  GetEnergy(t_matrix *ma)
 *
 * Arguments: ma - pointer to struct t_matrix
 *
 * Returns: int
 * Side-Effects: none
 *
 * Description: function to get agent energy of the puzzle
 *****************************************************************************/
int GetEnergy(t_matrix *ma){
	return ma->energy;
}
/******************************************************************************
 *  GetCellValue(t_matrix *ma, int l, int c)
 *
 * Arguments: ma - pointer to structure  t_matrix
 *			  l,c - initial position coordinates
 * Returns: (int)
 * Side-Effects: none
 *
 * Description: function to see the cost/prize of a certain cell
 *****************************************************************************/
int GetCellValue(t_matrix *ma, int l, int c){
	return ma->map[l][c].value;
}
/******************************************************************************
 *  GetCellUsage(t_matrix *ma, int l, int c)
 *
 * Arguments: ma - pointer to structure  t_matrix
 *			  l,c - initial position coordinates
 * Returns: (int)
 * Side-Effects: none
 *
 * Description: function to see flag visited associated with a certain cell
 *****************************************************************************/
int GetCellUsage(t_matrix *ma, int l, int c){
	return ma->map[l][c].visited;
}
/******************************************************************************
 *  CoordinateConvergence(t_cell *path,int k0, int l_p, int c_p)
 *
 * Arguments: path - pointer to array of structs t_cell
 *			  l_p,c_p - initial position coordinates
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: function to convert coordinates from the program sistem to the 
 * 	file's sistem.
 *
 *****************************************************************************/
void CoordinateConvergence(t_cell *path,int k0, int l_p, int c_p){
	
	int i;
	i=0;

	for(i=0; i<k0; i++){
		path[i].l=path[i].l+l_p+1;
		path[i].c=path[i].c+c_p+1;
	}
	return;
}
/******************************************************************************
 *  Visited(t_cell *path, t_matrix *ma, int k)
 *
 * Arguments: path - pointer to array of structs t_cell
 *			   ma - pointer to structure  t_matrix
 *			  k - placement of the wanted cell in the array
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: function reset flags of all the cell in the path 
 *****************************************************************************/
void Visited(t_cell *path, t_matrix *mat, int k){

	int i=0;

	for(i=0; i<k; i++)
		mat->map[path[i].l][path[i].c].visited=0;
	
	return;
}
/******************************************************************************
 *  transfer_path(t_cell *path, t_cell *ref_path, int k, int E)
 *
 * Arguments: path - pointer to array of structs t_cell
 *			  ref_path - pointer to array of structs t_cell with path with maximum energy
 *			  k - number of passes in path
 *			  E - final energy
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: function to transfer information of the path with new maximum energy
 *	to a vector (ref_path) in order to save it and compare it with other paths
 *****************************************************************************/
void transfer_path(t_cell *path, t_cell *ref_path, int k, int E){
	int i;
	i=0;

	ref_path[0].value=E; /*final energy for path*/
	for(i=0; i<k; i++){
		ref_path[i+1].value=path[i].value;
		ref_path[i+1].l=path[i].l;
		ref_path[i+1].c=path[i].c;
		ref_path[i+1].visited=1;
	}
	return;
}
/******************************************************************************
 *  path_transfer(t_cell *path, t_cell *ref_path, int k, int E)
 *
 * Arguments: path - pointer to array of structs t_cell
 *			  ref_path - pointer to array of structs t_cell with path with maximum energy
 *			  k - number of passes in path
 *			  E - final energy
 * Returns: (void)
 * Side-Effects: none
 *
 * Description: function to transfer information of the path with maximum energy
 *	(ref_path) to the normal vector in order to save it and write it in the output file
 *****************************************************************************/
void path_transfer(t_matrix *Mat, t_cell *path, t_cell *ref_path, int k, int E){
	int i;
	i=0;

	SetMapEnergy(Mat,ref_path[0].value); /*final path energy*/
	for(i=0; i<k; i++){
		path[i].value=ref_path[i+1].value;
		path[i].l=ref_path[i+1].l;
		path[i].c=ref_path[i+1].c;
		path[i].visited=1;
	}
	return;
}
